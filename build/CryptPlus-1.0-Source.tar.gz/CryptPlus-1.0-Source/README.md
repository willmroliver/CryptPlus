# CryptPlus

## About

CryptPlus is a lightweight wrappper of OpenSSL cryptographic tools. Specifically, the library aims to support symmetric encryption & decryption with AES-256 alongside Diffie-Hellman key exchange.

### Installation

- Install pre-built library

1. Download the *-Darwin.tar.gz package in `/build`
2. Unzip in a directory of your choosing

- Build from source (with CMake)

1. Download the *-Source.tar.gz package and unzip anywhere
2. From the command line, navigate to the build folder.
3. Execute the following line: `cmake --install .`
4. For UNIX, this will install to `/usr/local/libeventplus`. For WIN32, `c:/Program Files/libeventplus`